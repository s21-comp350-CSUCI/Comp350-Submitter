from django.apps import AppConfig


class InterpretorConfig(AppConfig):
    name = 'interpretor'
